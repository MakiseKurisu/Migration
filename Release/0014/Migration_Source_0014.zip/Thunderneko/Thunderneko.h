#pragma once

extern HMODULE hMyModule;
extern wchar_t DNFMutantName[];
extern wchar_t DNFLauncherMutantName[];
